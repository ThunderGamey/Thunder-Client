THUNDER MODERN - TEXTURES FOR THUNDER CLIENT (MINECRAFT 1.12.2)

Source:
Updated Textures 1.12 v1.4 (user-provided Modrinth pack)

Contents:
- Block and item textures under their Minecraft 1.12 names (pack_format 3)
- Original pack icon

Left out on purpose:
- Fire textures: the game's own animated fire is used, so fire never renders as the
  purple/black missing texture
- 1.12 blockstate/model files, OptiFine/MCPatcher CTM files and shader files

Checked with the Thunder Pack Doctor (thunder-pack-doctor.html).
This does NOT add newer Minecraft blocks or mechanics.
