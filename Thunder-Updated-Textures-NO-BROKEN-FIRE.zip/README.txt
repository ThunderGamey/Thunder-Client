THUNDER MODERN — 1.8-COMPATIBLE TEXTURE CONVERSION

Source:
Updated Textures 1.12 v1.4 (user-provided Modrinth pack)

What was converted:
- Block textures
- Item textures
- Original pack icon

What was intentionally left out:
- 1.12-specific blockstate/model files
- OptiFine/MCPatcher CTM files
- shader files
- 1.12-specific non-block/item systems

Reason:
The goal is to keep the modern-looking textures while avoiding newer resource-pack
features that can conflict with an older Eagler/Minecraft renderer.

This does NOT add newer Minecraft blocks or mechanics.
